package net.anubis.client.module.impl.render;

import it.unimi.dsi.fastutil.longs.Long2BooleanOpenHashMap;
import it.unimi.dsi.fastutil.longs.Long2IntMap;
import it.unimi.dsi.fastutil.longs.Long2IntOpenHashMap;
import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.longs.LongArrayFIFOQueue;
import it.unimi.dsi.fastutil.longs.LongArrayList;
import it.unimi.dsi.fastutil.longs.LongIterator;
import it.unimi.dsi.fastutil.longs.LongList;
import it.unimi.dsi.fastutil.longs.LongOpenHashSet;
import it.unimi.dsi.fastutil.objects.ObjectIterator;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.function.LongConsumer;
import net.anubis.client.event.EventHandler;
import net.anubis.client.event.impl.PacketAppliedEvent;
import net.anubis.client.event.impl.Render3DEvent;
import net.anubis.client.event.impl.TickEvent;
import net.anubis.client.module.ClientModule;
import net.anubis.client.module.ModuleCategory;
import net.anubis.client.module.setting.BooleanSetting;
import net.anubis.client.module.setting.ColorSetting;
import net.anubis.client.module.setting.ModeSetting;
import net.anubis.client.module.setting.NumberSetting;
import net.anubis.client.util.ChunkAreas;
import net.anubis.client.util.ChunkOverlay;
import net.anubis.client.util.GeodeGlowScan;
import net.anubis.client.util.LevelUtil;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1923;
import net.minecraft.class_1944;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2596;
import net.minecraft.class_2672;
import net.minecraft.class_2676;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2818;
import net.minecraft.class_2826;
import net.minecraft.class_310;
import net.minecraft.class_5543;
import net.minecraft.class_634;
import net.minecraft.class_638;
import net.minecraft.class_9848;

@Environment(EnvType.CLIENT)
public final class SusChunkFinderModule extends ClientModule {
   private static final long SCAN_BUDGET_NANOS = 3000000L;
   private static final int MIN_SCANNED_NEIGHBOURS = 3;
   private static final int NO_PACKET_SENSITIVITY = 1;
   private static final int VISIBLE_REFRESH_TICKS = 20;
   private static final int PACKET_MIN_Y = -16;
   private static final int PACKET_MAX_Y = 30;
   private static final String METHOD_CLASSIC = "Classic";
   private static final String METHOD_ANBS = "ANBS+ Scan";
   private static final int GLOW_CELLS_PER_POINT = 12;
   private static final int GEODE_TOP_Y = 47;
   private static final int MIN_EXPOSED_BUDDING = 10;
   private static final int MIN_EXPOSED_LINING = 160;
   private static final int GEODE_SETTLE_TICKS = 40;
   private static final int GEODE_CELL_SHIFT = 2;
   private static final int TORCH_LIGHT = 14;
   private static final class_2350[] SIDES = class_2350.values();
   private final ModeSetting method = (ModeSetting)this.addSetting("method", new ModeSetting("Method", "Classic", new String[]{"Classic", "ANBS+ Scan"}));
   private final NumberSetting spreadRadius = (NumberSetting)this.addSetting("spread-radius", (new NumberSetting("Simulation Distance", 5.0F, 2.0F, 16.0F)).step(1.0F));
   private final NumberSetting sensitivity = (NumberSetting)this.addSetting("packet-sensitivity", (new NumberSetting("Sensitivity", 6.0F, 1.0F, 20.0F)).step(1.0F));
   private final ColorSetting chunkColor = (ColorSetting)this.addSetting("chunk-color", new ColorSetting("Chunk Color", 1627325444));
   private final BooleanSetting tracers = (BooleanSetting)this.addSetting("tracers", new BooleanSetting("Tracers", true));
   private final BooleanSetting detectMined = (BooleanSetting)this.addSetting("detect-mined-clusters", new BooleanSetting("Detect Mined Clusters", false));
   private final ColorSetting minedColor = (ColorSetting)this.addSetting("mined-color", new ColorSetting("Mined Color", 1621511679));
   private final ChunkAreas chunkAreas = new ChunkAreas();
   private final ChunkOverlay chunkOverlay = new ChunkOverlay();
   private final ChunkAreas minedAreas = new ChunkAreas();
   private final ChunkOverlay minedOverlay = new ChunkOverlay();
   private final GeodeGlowScan glow = new GeodeGlowScan();
   private final Long2IntOpenHashMap heat = new Long2IntOpenHashMap();
   private final Long2IntOpenHashMap vetoes = new Long2IntOpenHashMap();
   private final Long2IntOpenHashMap chunkScore = new Long2IntOpenHashMap();
   private final Long2BooleanOpenHashMap chunkUngrown = new Long2BooleanOpenHashMap();
   private final Long2BooleanOpenHashMap chunkHasPacket = new Long2BooleanOpenHashMap();
   private final LongOpenHashSet scannedChunks = new LongOpenHashSet();
   private final LongArrayFIFOQueue queue = new LongArrayFIFOQueue();
   private final LongOpenHashSet queued = new LongOpenHashSet();
   private Long2IntOpenHashMap visible = new Long2IntOpenHashMap();
   private boolean visibleDirty = true;
   private int visibleAge;
   private class_638 lastLevel;
   private int appliedRadius;
   private final Long2ObjectOpenHashMap<GeodeSlice> geodeSlices = new Long2ObjectOpenHashMap();
   private final Long2IntOpenHashMap geodeWaiting = new Long2IntOpenHashMap();
   private final Long2IntOpenHashMap geodeScanTicks = new Long2IntOpenHashMap();
   private List<GeodeCluster> geodeClusters = List.of();
   private boolean geodeClustersDirty;
   private LongOpenHashSet minedChunks = new LongOpenHashSet();
   private int minedAge;
   private int ticks;

   public SusChunkFinderModule() {
      super("sus-chunk-finder", "Sus Chunk Finder", "Finds chunks with signs of player activity from fully grown amethyst.", ModuleCategory.BASE_RAID);
      this.method.onChange(this::rescan);
      this.sensitivity.onChange(() -> this.visibleDirty = true);
      this.detectMined.onChange(this::restartGeodes);
      ColorSetting var10000 = this.minedColor;
      BooleanSetting var10001 = this.detectMined;
      Objects.requireNonNull(var10001);
      var10000.visibleWhen(var10001::get);
   }

   private void rescan() {
      this.clearAll();
      this.queueLoadedChunks();
   }

   private void restartGeodes() {
      this.clearGeodes();
      if (this.detectMined.get()) {
         this.queueLoadedChunks();
      }

   }

   protected void onEnable() {
      this.clearAll();
      this.lastLevel = class_310.method_1551().field_1687;
      this.queueLoadedChunks();
   }

   protected void onDisable() {
      this.clearAll();
      this.lastLevel = null;
   }

   private void clearAll() {
      this.heat.clear();
      this.vetoes.clear();
      this.chunkScore.clear();
      this.chunkUngrown.clear();
      this.chunkHasPacket.clear();
      this.scannedChunks.clear();
      this.queue.clear();
      this.queued.clear();
      this.visible = new Long2IntOpenHashMap();
      this.visibleDirty = true;
      this.appliedRadius = this.spreadRadius.getInt();
      this.clearGeodes();
   }

   private void clearGeodes() {
      this.geodeSlices.clear();
      this.geodeWaiting.clear();
      this.geodeScanTicks.clear();
      this.geodeClusters = List.of();
      this.geodeClustersDirty = false;
      this.minedChunks = new LongOpenHashSet();
      this.minedAge = 0;
   }

   private void queueLoadedChunks() {
      class_310 mc = class_310.method_1551();
      if (mc.field_1687 != null && mc.field_1724 != null) {
         int radius = (Integer)mc.field_1690.method_42503().method_41753() + 1;
         class_1923 center = mc.field_1724.method_31476();

         for(int x = center.field_9181 - radius; x <= center.field_9181 + radius; ++x) {
            for(int z = center.field_9180 - radius; z <= center.field_9180 + radius; ++z) {
               if (LevelUtil.isLoaded(mc.field_1687, x, z)) {
                  this.enqueue(class_1923.method_8331(x, z));
               }
            }
         }

      }
   }

   private void enqueue(long key) {
      if (this.queued.add(key)) {
         this.queue.enqueue(key);
      }

   }

   @EventHandler
   public void onPacketApplied(PacketAppliedEvent event) {
      class_2596 var4 = event.packet;
      if (var4 instanceof class_2672 chunk) {
         this.enqueue(class_1923.method_8331(chunk.method_11523(), chunk.method_11524()));
      } else {
         var4 = event.packet;
         if (var4 instanceof class_2676 light) {
            if (this.method.is("ANBS+ Scan")) {
               this.enqueue(class_1923.method_8331(light.method_11558(), light.method_11554()));
            }
         }
      }

   }

   @EventHandler
   public void onTick(TickEvent event) {
      class_310 mc = class_310.method_1551();
      class_638 level = mc.field_1687;
      if (level != this.lastLevel) {
         this.clearAll();
         this.lastLevel = level;
         this.queueLoadedChunks();
      }

      if (level != null) {
         ++this.ticks;
         if (this.spreadRadius.getInt() != this.appliedRadius) {
            this.clearAll();
            this.queueLoadedChunks();
         }

         long deadline = System.nanoTime() + 3000000L;

         while(!this.queue.isEmpty() && System.nanoTime() < deadline) {
            long key = this.queue.dequeueLong();
            this.queued.remove(key);
            int cx = class_1923.method_8325(key);
            int cz = class_1923.method_8332(key);
            if (LevelUtil.isLoaded(level, cx, cz)) {
               this.updateChunk(key, level.method_8497(cx, cz), level);
               this.scannedChunks.add(key);
               this.visibleDirty = true;
            }
         }

         if (this.visibleDirty || ++this.visibleAge >= 20) {
            this.visible = this.computeVisible(level);
            this.visibleDirty = false;
            this.visibleAge = 0;
         }

         if (this.detectMined.get() && ++this.minedAge >= 20) {
            this.minedChunks = this.computeMined(level);
            this.minedAge = 0;
         }

      }
   }

   private void updateChunk(long key, class_2818 chunk, class_638 level) {
      int r = this.spreadRadius.getInt();
      int cx = class_1923.method_8325(key);
      int cz = class_1923.method_8332(key);
      int oldHeat = this.chunkScore.getOrDefault(key, 0);
      boolean oldUngrown = this.chunkUngrown.getOrDefault(key, false);
      if (oldHeat > 0) {
         forArea(cx, cz, r, (area) -> subtract(this.heat, area, oldHeat));
      }

      if (oldUngrown) {
         forArea(cx, cz, r, (area) -> subtract(this.vetoes, area, 1));
      }

      this.chunkHasPacket.put(key, hasBlocksInRange(chunk, -16, 30));
      ChunkScore score = this.scoreChunk(chunk, level);
      this.chunkScore.put(key, score.selfHeat());
      this.chunkUngrown.put(key, score.hasUngrown());
      if (score.hasUngrown()) {
         forArea(cx, cz, r, (area) -> this.vetoes.addTo(area, 1));
      }

      if (score.selfHeat() > 0) {
         forArea(cx, cz, r, (area) -> this.heat.addTo(area, score.selfHeat()));
      }

      if (this.detectMined.get()) {
         this.collectGeode(key, chunk, level);
      }

   }

   private static void forArea(int cx, int cz, int r, LongConsumer action) {
      for(int dx = -r; dx <= r; ++dx) {
         for(int dz = -r; dz <= r; ++dz) {
            action.accept(class_1923.method_8331(cx + dx, cz + dz));
         }
      }

   }

   private static void subtract(Long2IntOpenHashMap map, long key, int amount) {
      int left = map.get(key) - amount;
      if (left > 0) {
         map.put(key, left);
      } else {
         map.remove(key);
      }

   }

   private static boolean hasBlocksInRange(class_2818 chunk, int minY, int maxY) {
      class_2826[] sections = chunk.method_12006();
      int minSectionY = chunk.method_32891();

      for(int i = 0; i < sections.length; ++i) {
         class_2826 section = sections[i];
         if (section != null && !section.method_38292()) {
            int baseY = minSectionY + i << 4;
            if (baseY + 15 >= minY && baseY <= maxY) {
               for(int y = 0; y < 16; ++y) {
                  int worldY = baseY + y;
                  if (worldY >= minY && worldY <= maxY) {
                     for(int x = 0; x < 16; ++x) {
                        for(int z = 0; z < 16; ++z) {
                           if (!section.method_12254(x, y, z).method_26215()) {
                              return true;
                           }
                        }
                     }
                  }
               }
            }
         }
      }

      return false;
   }

   private ChunkScore scoreChunk(class_2818 chunk, class_638 level) {
      if (this.method.is("ANBS+ Scan")) {
         return new ChunkScore(this.glow.scan(level, chunk, (LongConsumer)null) / 12, false);
      } else {
         class_2826[] sections = chunk.method_12006();
         int minSectionY = chunk.method_32891();
         class_1923 pos = chunk.method_12004();
         boolean paletteOnly = isDonutFolia();
         int grown = 0;
         int ungrown = 0;
         boolean sawBud = false;
         boolean sawCluster = false;
         class_2338.class_2339 cursor = new class_2338.class_2339();

         for(int i = 0; i < sections.length; ++i) {
            class_2826 section = sections[i];
            if (section != null && !section.method_38292()) {
               if (paletteOnly) {
                  if (!sawBud && section.method_19523(SusChunkFinderModule::isBud)) {
                     sawBud = true;
                  }

                  if (!sawCluster && section.method_19523((statex) -> statex.method_27852(class_2246.field_27161))) {
                     sawCluster = true;
                  }
               } else if (section.method_19523(SusChunkFinderModule::isAmethystGrowth)) {
                  int baseY = minSectionY + i << 4;

                  for(int x = 0; x < 16; ++x) {
                     for(int y = 0; y < 16; ++y) {
                        for(int z = 0; z < 16; ++z) {
                           class_2680 state = section.method_12254(x, y, z);
                           if (state.method_27852(class_2246.field_27161)) {
                              ++grown;
                           } else if (isBud(state) && state.method_28498(class_2741.field_12525)) {
                              class_2350 facing = (class_2350)state.method_11654(class_2741.field_12525);
                              cursor.method_10103(pos.method_8326() + x, baseY + y, pos.method_8328() + z).method_10098(facing.method_10153());
                              if (level.method_8320(cursor).method_27852(class_2246.field_27160)) {
                                 ++ungrown;
                              } else {
                                 ++grown;
                              }
                           }
                        }
                     }
                  }
               }
            }
         }

         if (paletteOnly) {
            if (sawBud) {
               ++ungrown;
            } else if (sawCluster) {
               ++grown;
            }
         }

         return new ChunkScore(grown, ungrown > 0);
      }
   }

   private void collectGeode(long key, class_2818 chunk, class_638 level) {
      this.geodeScanTicks.put(key, this.ticks);
      if (this.geodeSlices.remove(key) != null) {
         this.geodeClustersDirty = true;
      }

      this.geodeWaiting.remove(key);
      int cx = class_1923.method_8325(key);
      int cz = class_1923.method_8332(key);

      for(int dx = -1; dx <= 1; ++dx) {
         for(int dz = -1; dz <= 1; ++dz) {
            long near = class_1923.method_8331(cx + dx, cz + dz);
            if ((dx != 0 || dz != 0) && (this.geodeWaiting.get(near) & waitBit(-dx, -dz)) != 0) {
               this.enqueue(near);
            }
         }
      }

      if (LevelUtil.isOverworld(level)) {
         class_2826[] sections = chunk.method_12006();
         int minSectionY = chunk.method_32891();
         int minX = cx << 4;
         int minZ = cz << 4;
         LongArrayList lining = new LongArrayList();
         LongArrayList budding = new LongArrayList();
         class_2338.class_2339 cursor = new class_2338.class_2339();
         int waiting = 0;

         for(int i = 0; i < sections.length; ++i) {
            int baseY = minSectionY + i << 4;
            if (baseY > 47) {
               break;
            }

            class_2826 section = sections[i];
            if (section != null && !section.method_38292() && section.method_19523(SusChunkFinderModule::isLining)) {
               for(int y = 0; y < 16; ++y) {
                  for(int z = 0; z < 16; ++z) {
                     for(int x = 0; x < 16; ++x) {
                        class_2680 state = section.method_12254(x, y, z);
                        if (isLining(state)) {
                           int wx = minX + x;
                           int wy = baseY + y;
                           int wz = minZ + z;
                           boolean exposed = false;
                           int missing = 0;

                           for(class_2350 side : SIDES) {
                              int nx = wx + side.method_10148();
                              int ny = wy + side.method_10164();
                              int nz = wz + side.method_10165();
                              if (!level.method_31601(ny)) {
                                 int ncx = nx >> 4;
                                 int ncz = nz >> 4;
                                 boolean inside = ncx == cx && ncz == cz;
                                 if (!inside && !LevelUtil.isLoaded(level, ncx, ncz)) {
                                    missing |= waitBit(ncx - cx, ncz - cz);
                                 } else {
                                    cursor.method_10103(nx, ny, nz);
                                    if (isOpen(inside ? chunk.method_8320(cursor) : level.method_8320(cursor))) {
                                       exposed = true;
                                       break;
                                    }
                                 }
                              }
                           }

                           if (!exposed) {
                              waiting |= missing;
                           } else {
                              long packed = class_2338.method_10064(wx, wy, wz);
                              lining.add(packed);
                              if (state.method_27852(class_2246.field_27160)) {
                                 budding.add(packed);
                              }
                           }
                        }
                     }
                  }
               }
            }
         }

         if (waiting != 0) {
            this.geodeWaiting.put(key, waiting);
         }

         if (!lining.isEmpty()) {
            this.geodeSlices.put(key, new GeodeSlice(lining.toLongArray(), budding.toLongArray()));
            this.geodeClustersDirty = true;
         }
      }
   }

   private static int waitBit(int dx, int dz) {
      return 1 << (dx + 1) * 3 + dz + 1;
   }

   private LongOpenHashSet computeMined(class_638 level) {
      if (this.geodeSlices.keySet().removeIf((key) -> !LevelUtil.isLoaded(level, class_1923.method_8325(key), class_1923.method_8332(key)))) {
         this.geodeClustersDirty = true;
      }

      this.geodeWaiting.keySet().removeIf((key) -> !LevelUtil.isLoaded(level, class_1923.method_8325(key), class_1923.method_8332(key)));
      this.geodeScanTicks.keySet().removeIf((key) -> !LevelUtil.isLoaded(level, class_1923.method_8325(key), class_1923.method_8332(key)));
      if (this.geodeClustersDirty) {
         this.geodeClusters = this.clusterGeodes();
         this.geodeClustersDirty = false;
      }

      LongOpenHashSet mined = new LongOpenHashSet();

      for(GeodeCluster cluster : this.geodeClusters) {
         boolean large = cluster.budding() > 0 ? cluster.budding() >= 10 : cluster.lining().length >= 160;
         if (large && this.settled(level, cluster) && unlit(level, cluster.lining())) {
            mined.add(cluster.chunk());
         }
      }

      return mined;
   }

   private List<GeodeCluster> clusterGeodes() {
      Long2ObjectOpenHashMap<LongArrayList> cells = new Long2ObjectOpenHashMap();
      LongOpenHashSet budding = new LongOpenHashSet();
      ObjectIterator var3 = this.geodeSlices.values().iterator();

      while(var3.hasNext()) {
         GeodeSlice slice = (GeodeSlice)var3.next();

         for(long packed : slice.lining()) {
            long cell = class_2338.method_10064(class_2338.method_10061(packed) >> 2, class_2338.method_10071(packed) >> 2, class_2338.method_10083(packed) >> 2);
            LongArrayList members = (LongArrayList)cells.get(cell);
            if (members == null) {
               cells.put(cell, members = new LongArrayList());
            }

            members.add(packed);
         }

         for(long packed : slice.budding()) {
            budding.add(packed);
         }
      }

      List<GeodeCluster> clusters = new ArrayList();
      LongOpenHashSet seen = new LongOpenHashSet();
      LongArrayFIFOQueue frontier = new LongArrayFIFOQueue();
      LongIterator var25 = cells.keySet().iterator();

      while(var25.hasNext()) {
         long start = (Long)var25.next();
         if (seen.add(start)) {
            LongArrayList lining = new LongArrayList();
            frontier.enqueue(start);

            while(!frontier.isEmpty()) {
               long cell = frontier.dequeueLong();
               lining.addAll((LongList)cells.get(cell));
               int x = class_2338.method_10061(cell);
               int y = class_2338.method_10071(cell);
               int z = class_2338.method_10083(cell);

               for(int dx = -1; dx <= 1; ++dx) {
                  for(int dy = -1; dy <= 1; ++dy) {
                     for(int dz = -1; dz <= 1; ++dz) {
                        long next = class_2338.method_10064(x + dx, y + dy, z + dz);
                        if (cells.containsKey(next) && seen.add(next)) {
                           frontier.enqueue(next);
                        }
                     }
                  }
               }
            }

            clusters.add(toCluster(lining.toLongArray(), budding));
         }
      }

      return clusters;
   }

   private static GeodeCluster toCluster(long[] lining, LongOpenHashSet budding) {
      int count = 0;
      int minX = Integer.MAX_VALUE;
      int minZ = Integer.MAX_VALUE;
      int maxX = Integer.MIN_VALUE;
      int maxZ = Integer.MIN_VALUE;
      long sumX = 0L;
      long sumZ = 0L;

      for(long packed : lining) {
         if (budding.contains(packed)) {
            ++count;
         }

         int x = class_2338.method_10061(packed);
         int z = class_2338.method_10083(packed);
         minX = Math.min(minX, x);
         minZ = Math.min(minZ, z);
         maxX = Math.max(maxX, x);
         maxZ = Math.max(maxZ, z);
         sumX += (long)x;
         sumZ += (long)z;
      }

      int centerX = (int)Math.floorDiv(sumX, lining.length);
      int centerZ = (int)Math.floorDiv(sumZ, lining.length);
      return new GeodeCluster(lining, count, minX, minZ, maxX, maxZ, class_1923.method_8331(centerX >> 4, centerZ >> 4));
   }

   private boolean settled(class_638 level, GeodeCluster cluster) {
      for(int cx = cluster.minX() - 1 >> 4; cx <= cluster.maxX() + 1 >> 4; ++cx) {
         for(int cz = cluster.minZ() - 1 >> 4; cz <= cluster.maxZ() + 1 >> 4; ++cz) {
            long key = class_1923.method_8331(cx, cz);
            if (!LevelUtil.isLoaded(level, cx, cz) || !this.geodeScanTicks.containsKey(key)) {
               return false;
            }

            if (this.ticks - this.geodeScanTicks.get(key) < 40) {
               return false;
            }
         }
      }

      return true;
   }

   private static boolean unlit(class_638 level, long[] lining) {
      class_2338.class_2339 cursor = new class_2338.class_2339();
      Long2IntOpenHashMap peaks = new Long2IntOpenHashMap();

      for(long packed : lining) {
         int x = class_2338.method_10061(packed);
         int y = class_2338.method_10071(packed);
         int z = class_2338.method_10083(packed);

         for(class_2350 side : SIDES) {
            cursor.method_10103(x + side.method_10148(), y + side.method_10164(), z + side.method_10165());
            if (isAmethystGrowth(level.method_8320(cursor))) {
               return false;
            }

            int light = level.method_8314(class_1944.field_9282, cursor);
            if (light > 0 && sourceLight(level, cursor, light, peaks) != 14) {
               return false;
            }
         }
      }

      return true;
   }

   private static int sourceLight(class_638 level, class_2338 start, int light, Long2IntOpenHashMap peaks) {
      LongArrayList path = new LongArrayList();
      class_2338.class_2339 at = start.method_25503();
      class_2338.class_2339 probe = new class_2338.class_2339();

      int peak;
      while(true) {
         long key = at.method_10063();
         if (peaks.containsKey(key)) {
            peak = peaks.get(key);
            break;
         }

         path.add(key);
         class_2350 uphill = null;
         int best = light;

         for(class_2350 side : SIDES) {
            int value = level.method_8314(class_1944.field_9282, probe.method_25505(at, side));
            if (value > best) {
               best = value;
               uphill = side;
            }
         }

         if (uphill == null) {
            peak = light;
            break;
         }

         at.method_10098(uphill);
         light = best;
      }

      for(int i = 0; i < path.size(); ++i) {
         peaks.put(path.getLong(i), peak);
      }

      return peak;
   }

   private static boolean isLining(class_2680 state) {
      return state.method_27852(class_2246.field_27159) || state.method_27852(class_2246.field_27160);
   }

   private static boolean isOpen(class_2680 state) {
      return class_5543.method_31626(state) || isAmethystGrowth(state);
   }

   private static boolean isBud(class_2680 state) {
      class_2248 block = state.method_26204();
      return block == class_2246.field_27164 || block == class_2246.field_27163 || block == class_2246.field_27162;
   }

   private static boolean isAmethystGrowth(class_2680 state) {
      return state.method_27852(class_2246.field_27161) || isBud(state);
   }

   private static boolean isDonutFolia() {
      class_634 connection = class_310.method_1551().method_1562();
      if (connection == null) {
         return false;
      } else {
         String brand = connection.method_52790();
         return brand != null && brand.contains("DonutFolia");
      }
   }

   private Long2IntOpenHashMap computeVisible(class_638 level) {
      Long2IntOpenHashMap eligible = new Long2IntOpenHashMap();
      ObjectIterator var3 = this.heat.long2IntEntrySet().iterator();

      while(var3.hasNext()) {
         Long2IntMap.Entry entry = (Long2IntMap.Entry)var3.next();
         long key = entry.getLongKey();
         if (!this.vetoes.containsKey(key)) {
            int cx = class_1923.method_8325(key);
            int cz = class_1923.method_8332(key);
            if (LevelUtil.isLoaded(level, cx, cz) && this.scannedNeighbours(cx, cz) >= 3) {
               eligible.put(key, entry.getIntValue());
            }
         }
      }

      int withPacket = this.sensitivity.getInt();
      int reach = this.appliedRadius;
      Long2IntOpenHashMap kept = new Long2IntOpenHashMap();
      ObjectIterator var6 = eligible.long2IntEntrySet().iterator();

      while(var6.hasNext()) {
         Long2IntMap.Entry entry = (Long2IntMap.Entry)var6.next();
         long key = entry.getLongKey();
         int value = entry.getIntValue();
         int threshold = this.chunkHasPacket.getOrDefault(key, true) ? withPacket : 1;
         if (value >= threshold && isPeak(eligible, key, value, reach)) {
            kept.put(key, value);
         }
      }

      return kept;
   }

   private static boolean isPeak(Long2IntOpenHashMap field, long key, int value, int reach) {
      int cx = class_1923.method_8325(key);
      int cz = class_1923.method_8332(key);

      for(int dx = -reach; dx <= reach; ++dx) {
         for(int dz = -reach; dz <= reach; ++dz) {
            if ((dx != 0 || dz != 0) && field.get(class_1923.method_8331(cx + dx, cz + dz)) > value) {
               return false;
            }
         }
      }

      return true;
   }

   private int scannedNeighbours(int cx, int cz) {
      int count = 0;

      for(int dx = -1; dx <= 1; ++dx) {
         for(int dz = -1; dz <= 1; ++dz) {
            if ((dx != 0 || dz != 0) && this.scannedChunks.contains(class_1923.method_8331(cx + dx, cz + dz))) {
               ++count;
            }
         }
      }

      return count;
   }

   @EventHandler
   public void onRender3D(Render3DEvent event) {
      if (class_310.method_1551().field_1687 != null) {
         this.chunkOverlay.draw(this.visible.keySet(), this.chunkColor.argb(), event.partialTick);
         if (this.tracers.get()) {
            this.chunkAreas.drawTracers(this.visible.keySet(), (double)63.0F, class_9848.method_61334(this.chunkColor.argb()));
         }

         this.minedOverlay.draw(this.minedChunks, this.minedColor.argb(), event.partialTick);
         if (this.tracers.get()) {
            this.minedAreas.drawTracers(this.minedChunks, (double)63.0F, class_9848.method_61334(this.minedColor.argb()));
         }

      }
   }

   @Environment(EnvType.CLIENT)
   private static record ChunkScore(int selfHeat, boolean hasUngrown) {
   }

   @Environment(EnvType.CLIENT)
   private static record GeodeSlice(long[] lining, long[] budding) {
   }

   @Environment(EnvType.CLIENT)
   private static record GeodeCluster(long[] lining, int budding, int minX, int minZ, int maxX, int maxZ, long chunk) {
   }
}
